
(function() {
  'use strict';

  angular.module('angularMaterialApp', ['ngMaterial','ngMessages','ngMaterialSidemenu'])
   .config(($mdIconProvider, $mdThemingProvider) => {
    // Register the user `avatar` icons
    $mdIconProvider
      .icon("menu", "./images/menu.svg", 24)
      
  })
      .controller('AppCtrl', AppCtrl);

  function AppCtrl($scope,$mdSidenav) {
	  
	  
    $scope.currentNavItem = 'page2';
	
	    $scope.toggleList = function () {
		
    $mdSidenav('left').toggle();
        }
	
	  

	
  }

})();